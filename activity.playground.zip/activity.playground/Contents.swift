import UIKit

var digits = [10.8, 45.5, 23,40]
let sum:Double = digits.reduce(0, +)
digits.count
let avg:Double = Double(sum) / Double(digits.count)
print("The average of the given numbers are: \(avg)")
