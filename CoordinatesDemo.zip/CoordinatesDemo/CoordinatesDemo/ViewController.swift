//
//  ViewController.swift
//  CoordinatesDemo
//
//  Created by Myla,Niharica on 3/1/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ImageViewOutlet: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let minx = ImageViewOutlet.frame.minX;
        let miny = ImageViewOutlet.frame.minY;
        print(minx,",", miny);
        
        let maxx = ImageViewOutlet.frame.maxX;
        let maxy = ImageViewOutlet.frame.maxY;
        print(maxx, ",", maxy);
        
        let midx = ImageViewOutlet.frame.midX;
        let midy = ImageViewOutlet.frame.midY;
        print(midx, ",", midy);
        
        //move the location of the object to the upper left corner which is (0,0);
        ImageViewOutlet.frame.origin.x = 0
        ImageViewOutlet.frame.origin.y = 0
     
        //move the location of the object to the upper left corner which is (414,0);
        ImageViewOutlet.frame.origin.x = 414
        ImageViewOutlet.frame.origin.y = 0
        
        //move the location of the object to the upper right corner which is (414,0);
        ImageViewOutlet.frame.origin.x = 314
        ImageViewOutlet.frame.origin.y = 0
        
        //move the location of the object to the lower left corner which is (0, 796);
        ImageViewOutlet.frame.origin.x = 0
        ImageViewOutlet.frame.origin.y = 796
        
        
        //move the location of the object to the lower right corner which is (314, 796);
        ImageViewOutlet.frame.origin.x = 314
        ImageViewOutlet.frame.origin.y = 796
        
        //move the location of the object to the center which is (314, 796);
        ImageViewOutlet.frame.origin.x = 164
        ImageViewOutlet.frame.origin.y = 317
        
        //move the location of the object to the center which is (414/2=207, 896/2=);
        ImageViewOutlet.frame.origin.x = 207
        ImageViewOutlet.frame.origin.y = 448
        //why 398?? it should be 448
        
        //move the location of the object to the center which is ((414/2)-50)=207, (896/2)-50);
        ImageViewOutlet.frame.origin.x = 157
        ImageViewOutlet.frame.origin.y = 398
        
        
        
    }


}

