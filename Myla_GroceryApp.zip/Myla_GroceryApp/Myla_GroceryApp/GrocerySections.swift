//
//  GrocerySections.swift
//  Myla_GroceryApp
//
//  Created by Myla,Niharica on 4/5/22.
//

import Foundation

struct GrocerySections {
    var section = ""
    var groceryItem:[GroceryItem] = []
}
struct GroceryItem {
    var itemName = ""
    var itemImage = ""
    var itemInfo = ""
}

//Populating grocery items details using struct
let section1 = GrocerySections(section: "Meat & Sea Food",  groceryItem:[GroceryItem(itemName: "Chicken", itemImage: "chicken", itemInfo: "Chickens are the most common birds on earth. Chicken meat contains low collagen levels, which is another positive characteristic. Collagen is a structural protein that reduces meat digestibility, so chicken meat is easier to digest than other types of meat. Chicken meat is also a good source of some minerals and vitamins"),
GroceryItem(itemName: "Fish", itemImage: "fish", itemInfo: "Fish is the flesh of an animal used for food, and by that definition, it's meat. However, many religions don't consider it meat. There are also several important distinctions between fish and other types of meat, especially in terms of their nutritional profiles and potential health benefits."),
GroceryItem(itemName: "Turkey", itemImage: "turkey", itemInfo: "Turkey is a popular meat that boasts high-quality protein, B vitamins, selenium, zinc, and phosphorus. It may support various aspects of health, including muscle growth and maintenance, due to its rich supply of nutrients. However, it's best to avoid processed varieties, as these are high in salt."),
GroceryItem(itemName: "Beef", itemImage: "beef", itemInfo: "Beef is the meat of cattle (Bos taurus). It is categorized as red meat — a term used for the meat of mammals, which contains higher amounts of iron than chicken or fish. Usually eaten as roasts, ribs, or steaks, beef is also commonly ground or minced. Patties of ground beef are often used in hamburgers."),
GroceryItem(itemName: "Ham", itemImage: "ham", itemInfo: "ham, the rear leg of a hog prepared as food, either fresh or preserved through a curing process that involves salting, smoking, or drying. The two hams constitute about 18–20 percent of the weight of a pork carcass.")])

let section2 = GrocerySections(section: "Fruits",  groceryItem:[GroceryItem(itemName: "Apple", itemImage: "apple", itemInfo: "An apple is an edible fruit produced by an apple tree. Apple trees are cultivated worldwide and are the most widely grown species in the genus Malus. The tree originated in Central Asia, where its wild ancestor, Malus sieversii, is still found today."),
GroceryItem(itemName: "Kiwi", itemImage: "kiwi", itemInfo: "kiwi, (Actinidia deliciosa), also called kiwifruit or Chinese gooseberry, woody vine and edible fruit of the family Actinidiaceae. The plant is native to mainland China and Taiwan and is also grown commercially in New Zealand and California. The fruit has a slightly acid taste and can be eaten raw or cooked."),
GroceryItem(itemName: "Orange", itemImage: "orange", itemInfo: "An orange is a fruit of various citrus species in the family Rutaceae; it primarily refers to Citrus × sinensis, which is also called sweet orange, to distinguish it from the related Citrus × aurantium, referred to as bitter orange."),
 GroceryItem(itemName: "Banana", itemImage: "banana", itemInfo: "A banana is an elongated, edible fruit – botanically a berry – produced by several kinds of large herbaceous flowering plants in the genus Musa. In some countries, bananas used for cooking may be called plantains, distinguishing them from dessert bananas."),
 GroceryItem(itemName: "BlueBerry", itemImage: "blueberry", itemInfo: "Blueberries contain a plant compound called anthocyanin. This gives blueberries both their blue color and many of their health benefits. Blueberries can help heart health, bone strength, skin health, blood pressure, diabetes management, cancer prevention, and mental health.")])

let section3 = GrocerySections(section: "Frozen Food",  groceryItem:[GroceryItem(itemName: "Frozen Pizza", itemImage: "pizza", itemInfo: " Experts for the consumer group analysed 162 cheese-and-tomato and pepperoni pizzas available in the major supermarkets and takeaway chains, finding that frozen pizzas tended to be healthier than fresh versions."),
GroceryItem(itemName: "Ice Cream", itemImage: "icecream", itemInfo: "Ice cream is a mixture of milk, cream, sugar, and sometimes other ingredients that has been frozen into a soft, creamy delight using special techniques. Ice cream has been a popular treat for hundreds of years but has only become commonplace since the widespread use of refrigeration."),
GroceryItem(itemName: "Frozen Fruits", itemImage: "fruits", itemInfo: "Depending on the fruit, some may retain more nutrients frozen while others are better fresh. Nutrients in fruit are at their peak right after being picked. Because fruit is frozen quickly, it retains nutritional value. If your fresh fruit is truly fresh, the nutrient value may be similar"),
 GroceryItem(itemName: "Frozen Vegetables", itemImage: "veg", itemInfo: "Frozen vegetables are vegetables that have had their temperature reduced and maintained to below their freezing point for the purpose of storage and transportation."),
 GroceryItem(itemName: "Frozen Fish&Meat", itemImage: "fishnmeat", itemInfo: "Freezing food preserves it from the time it is prepared to the time it is eaten. Since early times, farmers, fishermen, and trappers have preserved grains and produce in unheated buildings during the winter season.")])
let section4 = GrocerySections(section: "Vegetables",  groceryItem:[GroceryItem(itemName: "Peas", itemImage: "peas", itemInfo: " The pea is most commonly the small spherical seed or the seed-pod of the pod fruit Pisum sativum. Each pod contains several peas, which can be green or yellow. Botanically, pea pods are fruit, since they contain seeds and develop from the ovary of a flower."),
GroceryItem(itemName: "Spinach", itemImage: "spinach", itemInfo: "ISpinach (Spinacia oleracea) is a leafy green vegetable that originated in Persia. It belongs to the amaranth family and is related to beets and quinoa. What's more, it's considered very healthy, as it's loaded with nutrients and antioxidants."),
GroceryItem(itemName: "Onions", itemImage: "onion", itemInfo: "The onion, also known as the bulb onion or common onion, is a vegetable that is the most widely cultivated species of the genus Allium. The shallot is a botanical variety of the onion which was classified as a separate species until 2010. Its close relatives include garlic, scallion, leek, chive, and Chinese onion."),
 GroceryItem(itemName: "Carrots", itemImage: "car", itemInfo: "The carrot (Daucus carota) is a root vegetable often claimed to be the perfect health food. It is crunchy, tasty, and highly nutritious. Carrots are a particularly good source of beta carotene, fiber, vitamin K1, potassium, and antioxidants ( 1 ). They also have a number of health benefits."),
 GroceryItem(itemName: "Brocolli", itemImage: "bro", itemInfo: "Broccoli is an edible green plant in the cabbage family whose large flowering head, stalk and small associated leaves are eaten as a vegetable. Broccoli is classified in the Italica cultivar group of the species Brassica oleracea.")])

let section5 = GrocerySections(section: "Beverages",  groceryItem:[GroceryItem(itemName: "Tea", itemImage: "tea", itemInfo: " Tea is an aromatic beverage prepared by pouring hot or boiling water over cured or fresh leaves of Camellia sinensis, an evergreen shrub native to China, India and other East Asian countries. Tea is also rarely made from the leaves of Camellia taliensis. After water, it is the most widely consumed drink in the world."),
GroceryItem(itemName: "Coffee", itemImage: "coffee", itemInfo: "ICoffee is darkly colored, bitter, slightly acidic and has a stimulating effect in humans, primarily due to its caffeine content. It is one of the most popular drinks in the world and can be prepared and presented in a variety of ways ."),
GroceryItem(itemName: "Mocktails", itemImage: "mocktail", itemInfo: "Consider making a “mocktail.” Mocktails are simply cocktails without the liquor – they use a variety of tasty ingredients to create a flavor fusion, providing a sophisticated beverage sans alcohol. Whether you imbibe or not, mocktails can be a treat for any social gathering or night in."),
 GroceryItem(itemName: "Sparkling Water", itemImage: "water", itemInfo: "To make water “sparkling,” it's infused with carbon dioxide gas under pressure. Different forms of sparkling water include club soda (which often has added minerals), soda water, and seltzer water. The carbonation makes it similar to soft drinks, but with far fewer calories."),
 GroceryItem(itemName: "Milkshakes", itemImage: "milkshake", itemInfo: "A milkshake (sometimes simply called a shake) is a sweet drink made by blending milk, ice cream, and flavorings or sweeteners such as butterscotch, caramel sauce, chocolate syrup, fruit syrup, or whole fruit into a thick, sweet, cold mixture.")])

// grocery array we use in the LoginController
let groceries = [section1, section2, section3, section4, section5]
