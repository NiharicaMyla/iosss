//
//  GrocerySections.swift
//  Myla_GroceryApp
//
//  Created by Myla,Niharica on 4/5/22.
//

import Foundation

struct GrocerySections {
    var section = ""
    var groceryItem:[GroceryItem] = []
}
struct GroceryItem {
    var itemName = ""
    var itemImage = ""
    var itemInfo = ""
}

let section1 = GrocerySections(section: "Meat & Sea Food", GroceryItem: [itemName: "Chicken", itemImage: <#T##String#>, itemInfo: String:]
                       
                        GroceryItem(title:"Data Structures",sem:"sp22"),
                        GroceryItem(title:"Big Data",sem:"sp22")
                       ])

