//
//  ViewController.swift
//  Myla_GroceryApp
//
//  Created by Myla,Niharica on 4/5/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

