//
//  ViewController.swift
//  Myla_GroceryApp
//
//  Created by Myla,Niharica on 4/5/22.
//

import UIKit

class GroceryDetails{
    var productName : String?
    var productCategory : String?
    init(productName: String, productCategory: String){
        self.productName = productName
        self.productCategory = productCategory
    }
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        <#code#>
    }
    
    var productArray = [GroceryDetails]()
    @IBOutlet weak var Grocerysectiontable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        Grocerysectiontable.delegate = self
        Grocerysectiontable.dataSource = self
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "itemsSegue"{
            let destination = segue.destination as! GroceryItemsViewController
            destination.groceries = productArray[(tableViewOutlet.indexPathForSelectedRow?.row)!]
        }}
}

