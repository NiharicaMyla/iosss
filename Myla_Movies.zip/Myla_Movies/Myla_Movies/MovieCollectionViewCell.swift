//
//  MovieCollectionViewCell.swift
//  Myla_Movies
//
//  Created by Myla,Niharica on 4/21/22.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
}
