//
//  CreateContactViewController.swift
//  Myla_ContactList
//
//  Created by Myla,Niharica on 4/26/22.
//

import UIKit

class CreateContactViewController: UIViewController {
    @IBOutlet weak var custNmae: UITextField!
    
    @IBOutlet weak var CUstNum: UITextField!
    
    @IBOutlet weak var addbtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //custNmae.text = UITableView
        
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        //tableView.reloadData()
    }

    @IBAction func AddButton(_ sender: Any) {
        var ar = ["add","9087654321"]
         contacts.append(ar)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    }

