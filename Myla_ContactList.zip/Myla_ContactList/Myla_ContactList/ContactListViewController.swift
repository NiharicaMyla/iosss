//
//  ViewController.swift
//  Myla_ContactList
//
//  Created by Myla,Niharica on 4/26/22.
//

import UIKit

class ContactListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contacts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "contactCell", for: indexPath)
        //populate cell
        cell.textLabel?.text = contactNames[indexPath.row]
        //return cell
        return cell
    }
    var contactNames : [String] = []
    var contacts = NSDictionary()
   // contacts.append

    @IBOutlet weak var createContactbtn: UIButton!
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        // Do any additional setup after loading the view.
            //createButton()
    }

    @IBAction func createButton(_ sender: UIButton) {
       

            
        }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transistion = segue.identifier
        if transistion == "contactDetailsSegue"{
            let destination = segue.destination as! ContactDetailsViewController
            //let contactClicked =
    }
    
}
}
