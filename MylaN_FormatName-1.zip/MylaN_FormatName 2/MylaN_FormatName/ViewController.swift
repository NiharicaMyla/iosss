//
//  ViewController.swift
//  MylaN_FormatName
//
//  Created by Myla,Niharica on 1/31/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstNameTextField: UITextField!
   
    
    @IBOutlet weak var lastNameTextField: UITextField!
   
    
    @IBOutlet weak var fullNameLabel: UILabel!
  
    
    
    @IBOutlet weak var initialsLabel: UILabel!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func onClickOfSubmit(_ sender: UIButton) {
        fullNameLabel.text = lastNameTextField.text! + "," + firstNameTextField.text!
        //initialsLabel.text = "\(firstNameTextField.text.first)\(lastNameTextField.text.first)"
        initialsLabel.text = "\(firstNameTextField.text!.first!)\(lastNameTextField.text!.first!)"
    }
    
    
    @IBAction func onClickOfReset(_ sender: UIButton) {
        firstNameTextField.text = ""
        lastNameTextField.text = ""
        fullNameLabel.text = ""
        initialsLabel.text = ""
        
        
    }
    
    
    
    
    
    
}

