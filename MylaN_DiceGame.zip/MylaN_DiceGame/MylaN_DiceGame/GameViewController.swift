//
//  GameViewController.swift
//  MylaN_DiceGame
//
//  Created by Myla,Niharica on 4/7/22.
//

import UIKit

class GameViewController: UIViewController {

    @IBOutlet weak var play1: UILabel!
    
    @IBOutlet weak var play2: UILabel!
    
    @IBOutlet weak var playbutton: UIButton!
    
    @IBOutlet weak var player1score: UILabel!
    
    @IBOutlet weak var player2score: UILabel!
    
    @IBOutlet weak var image: UIImageView!
    
    var firstpname = ""
    var secondpname = ""
    var fcount = 0
    var scount = 0
    
    var img = ["play","dice1","dice2","dice3","dice4","dice5","dice6","tie"]
    override func viewDidLoad() {
        super.viewDidLoad()

        play1.text = "Total number of games \(firstpname) won: \(fcount)"
        play2.text = "Total number of games \(secondpname) won: \(scount)"
        
        player1score.text = "\(firstpname) current score: nill"
        player2score.text = "\(secondpname) current score: nill"
        image.image = UIImage(named: img[0])
        // Do any additional setup after loading the view.
    }
    
    @IBAction func Playmebutton(_ sender: UIButton) {
      
        let arr = [1,2,3,4,5,6]
        let p1:Int = arr.randomElement() ?? 0
        let p2:Int = arr.randomElement() ?? 0
        player1score.text = "\(firstpname) current score: \(p1)"
        player2score.text = "\(secondpname) current score: \(p2)"
        if(p1 == p2){
            image.image = UIImage(named: img[7])
        }
        else if(p1 > p2){
            fcount = fcount + 1
            player1score.text = "\(firstpname) current score: \(p1)"
            image.image = UIImage(named: img[p1])
            play1.text = "Total number of games \(firstpname) won: \(fcount)"
        }
        else if(p1 < p2){
            scount = scount + 1
            player2score.text = "\(secondpname) current score: \(p2)"
            image.image = UIImage(named: img[p2])
            player2score.text = "Total number of games \(secondpname) won: \(scount)"
        }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
