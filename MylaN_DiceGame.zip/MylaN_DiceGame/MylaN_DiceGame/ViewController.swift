//
//  ViewController.swift
//  MylaN_DiceGame
//
//  Created by Myla,Niharica on 4/7/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var player1: UITextField!
    
    
    @IBOutlet weak var player2: UITextField!
    
    
    @IBOutlet weak var clickbutton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonClicked(_ sender: UIButton) {
        
        var fpname = player1.text!
        var spname = player2.text!
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var tran = segue.identifier
        if tran == "diceSegue"{
            
            var desti = segue.destination as! GameViewController
            desti.firstpname = player1.text!
            desti.secondpname = player2.text!
           
        }
    }
    
}
              

    
