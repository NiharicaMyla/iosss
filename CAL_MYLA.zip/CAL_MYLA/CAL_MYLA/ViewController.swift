//
//  ViewController.swift
//  CAL_MYLA
//
//  Created by Myla,Niharica on 2/17/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    
    }

    @IBOutlet weak var display: UILabel!
    var operand1:Double = -1.1;
    var operand2:Double = -1.1;
    var CalcOperator:Character = " ";
    
    @IBAction func AC(_ sender: UIButton) {
    }
    
    
    @IBAction func div(_ sender: UIButton) {
        display.text = display.text! + "÷"
    }
    

    @IBAction func plusormin(_ sender: UIButton) {
    }
    
    @IBAction func clear(_ sender: UIButton) {
        
    }
    
    
    @IBAction func zero(_ sender: UIButton) {
        display.text = display.text! + "0"
    }
    
    @IBAction func dot(_ sender: UIButton) {
        display.text = display.text! + "."
    }
    
    
    @IBAction func equal(_ sender: UIButton) {
        display.text = display.text! + "="
    }
    
    
    @IBAction func one(_ sender: UIButton) {
        display.text = display.text! + "1"
        
            }
    
    
    @IBAction func two(_ sender: UIButton) {
        display.text = display.text! + "2"
    }
    
    
    @IBAction func three(_ sender: UIButton) {
        display.text = display.text! + "3"
    }
    
    
    @IBAction func plus(_ sender: UIButton) {
        display.text = display.text! + "+"
    }
    
    
    @IBAction func four(_ sender: UIButton) {
        display.text = display.text! + "5"
    }
    
    
    @IBAction func five(_ sender: UIButton) {
        display.text = display.text! + "5"
    }
    
    @IBAction func six(_ sender: UIButton) {
        display.text = display.text! + "6"
    }
    
    @IBAction func minus(_ sender: UIButton) {
        display.text = display.text! + "-"
    }
    
    @IBAction func seven(_ sender: UIButton) {
        display.text = display.text! + "7"
    }
    
    
    @IBAction func eight(_ sender: UIButton) {
        display.text = display.text! + "8"
    }
    
    
    @IBAction func nine(_ sender: UIButton) {
        display.text = display.text! + "9"
    }
    
    
    @IBAction func multi(_ sender: UIButton) {
        display.text = display.text! + "*"
    }
    
   
    @IBAction func percent(_ sender: UIButton) {
        display.text = display.text! + "%"
    }
    
    
    
    
    
    
    
    
    
    
    
}

