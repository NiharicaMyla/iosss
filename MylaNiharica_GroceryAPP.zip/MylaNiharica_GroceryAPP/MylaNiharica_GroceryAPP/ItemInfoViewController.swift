//
//  ItemInfoViewController.swift
//  MylaNiharica_GroceryAPP
//
//  Created by Myla,Niharica on 4/12/22.
//

import UIKit

class ItemInfoViewController: UIViewController {

    var Gdetails : GroceryItem?

    @IBOutlet weak var itemImageViewOutlet: UIImageView!
    
    @IBOutlet weak var showItemInfoAction: UIButton!
    
    @IBOutlet weak var itemInfoOutlet: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = Gdetails?.itemName
     
        var imagess = Gdetails?.itemImage
        itemImageViewOutlet.image = UIImage(named: imagess!)
        let imgFrame = itemImageViewOutlet.frame
        let width1: CGFloat = 30
        let height1: CGFloat = 30
        let newimg = CGRect(
        x: itemImageViewOutlet.frame.origin.x + width1,
        y: itemImageViewOutlet.frame.origin.y + height1,
        width: itemImageViewOutlet.frame.width - width1,
        height: itemImageViewOutlet.frame.height - height1)
        itemImageViewOutlet.frame = newimg
        UIView.animate(withDuration: 0.9, delay: 0.5, usingSpringWithDamping: 0.2, initialSpringVelocity: 40.0,  animations: {
                        self.itemImageViewOutlet.frame = imgFrame
                    })
            
        }
    
    @IBAction func buttonGetInfo(_ sender: Any) {
        itemInfoOutlet.text = Gdetails?.itemInfo
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
