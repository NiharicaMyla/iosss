//
//  ViewController.swift
//  MylaNiharica_GroceryAPP
//
//  Created by Myla,Niharica on 4/12/22.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productArray.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = grocerySectionsTableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        cell.textLabel?.text = productArray[indexPath.row].section
        return cell
    }
    
    var Groc = GrocerySections()
    
    var productArray = groceries
    @IBOutlet weak var grocerySectionsTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.title = "😋Grocery-List for you🥰"
        grocerySectionsTableView.delegate = self
        grocerySectionsTableView.dataSource = self
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "itemSegue"{
            let destination = segue.destination as! GroceryItemsViewController
            destination.Gitems = productArray[(grocerySectionsTableView.indexPathForSelectedRow?.row)!]
        }}
}

