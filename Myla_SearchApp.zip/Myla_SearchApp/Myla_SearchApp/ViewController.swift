//
//  ViewController.swift
//  Myla_SearchApp
//
//  Created by Myla,Niharica on 3/1/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

