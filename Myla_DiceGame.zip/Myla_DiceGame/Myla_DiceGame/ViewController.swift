//
//  ViewController.swift
//  Myla_DiceGame
//
//  Created by Myla,Niharica on 2/24/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var player1: UITextField!
    
    @IBOutlet weak var player2: UITextField!
    
    @IBOutlet weak var no1: UILabel!
    
    @IBOutlet weak var no2: UILabel!
    
    @IBOutlet weak var won: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading
    //the view.
    
    }

    @IBAction func roll(_ sender: UIButton) {
        
    var a = Int.random(in: 1...6)
        var b = Int.random(in: 1...6)
    
        
        var dice = Int.random(in: 1 ... 6)
        while dice > 1 {
            print(no1.text)
            if dice == 1 {
                break
            } else {
                dice = Int.random(in: 1 ... 6)
            }
            print(no2.text)
            }
        }
    }
    

    
    
    
    
    


