//
//  PianoViewController.swift
//  MusicPlay
//
//  Created by student on 4/4/22.
//

import UIKit

class PianoVC: UIViewController {

   

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

   
   


}
