//
//  ViewController.swift
//  MusicPlay
//
//  Created by student on 4/4/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var displayImage: UIImageView!
    
    @IBOutlet weak var titleLabel: UILabel!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var startButton: UIButton!
}

