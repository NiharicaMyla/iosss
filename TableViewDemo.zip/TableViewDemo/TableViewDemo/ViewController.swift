//
//  ViewController.swift
//  TableViewDemo
//
//  Created by Myla,Niharica on 3/29/22.
//

import UIKit

class AppleProducts{
    var productName : String?
    var productCategory : String?
    init(productName: String, productCategory: String){
        self.productName = productName
        self.productCategory = productCategory
    }
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //return the cell with data
        //create cells dynamically
        let cell = tableViewOutlet.dequeueReusableCell(withIdentifier: "reusableCell", for: indexPath)
        //assign the data to the cell
        cell.textLabel?.text = productArray[indexPath.row].productName
        return cell
    }
    
var productArray = [AppleProducts]()
    @IBOutlet weak var tableViewOutlet: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tableViewOutlet.delegate = self
        tableViewOutlet.dataSource = self
        
        let product1 = AppleProducts(productName: "MacbookAir", productCategory: "Laptop")
        productArray.append(product1)
        let product2 = AppleProducts(productName: "Windows", productCategory: "Desktop")
        productArray.append(product2)
        let product3 = AppleProducts(productName: "IPhone", productCategory: "MobilePhone")
        productArray.append(product3)
        let product4 = AppleProducts(productName: "Airpods", productCategory: "Accessories")
        productArray.append(product4)
        let product5 = AppleProducts(productName: "Comics", productCategory: "Books")
        productArray.append(product5)
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "detailsSegue"{
            let destination = segue.destination as! DetailsViewController
            destination.products = productArray[(tableViewOutlet.indexPathForSelectedRow?.row)!]
        }
    }

}

