import Cocoa

var str = "Hello, playground"
print(str)
