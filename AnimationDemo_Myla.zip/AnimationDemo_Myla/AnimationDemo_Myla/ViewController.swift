//
//  ViewController.swift
//  AnimationDemo_Myla
//
//  Created by Myla,Niharica on 3/15/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var imageview: UIImageView!
    
    
    @IBOutlet weak var happy: UIButton!
    
    @IBOutlet weak var sad: UIButton!
    
    
    @IBOutlet weak var angry: UIButton!
    
    
    @IBOutlet weak var shakeme: UIButton!
    
    @IBOutlet weak var show: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func HappyButton(_ sender: UIButton) {
    }
    
    
    @IBAction func SadButton(_ sender: UIButton) {
    }
    
    
    
    @IBAction func ShowButton(_ sender: UIButton) {
    }
    
    
    @IBAction func AngryButton(_ sender: UIButton) {
    }
    
    
    
    @IBAction func ShakeMeButton(_ sender: UIButton) {
    }
    
    
    
    
    
    
    

}

