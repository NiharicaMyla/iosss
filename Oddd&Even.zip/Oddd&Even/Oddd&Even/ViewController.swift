//
//  ViewController.swift
//  Oddd&Even
//
//  Created by Myla,Niharica on 2/8/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Digits: UITextField!
    @IBOutlet weak var DisplayLabel: UILabel!
    @IBOutlet weak var Output: UILabel!
 
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view
        
    }

    @IBAction func Submit(_ sender: Any) {
        var num = Int (Digits.text!)
       
        if num! % 2 == 0 {
            Output.text = "\(num!) is an Even Number."
        } else {
            Output.text = "\(num!) is an Even Number."
        }
    }
    
}

