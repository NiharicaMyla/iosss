//
//  ViewController.swift
//  StudentApp
//
//  Created by Myla,Niharica on 3/24/22.
//

import UIKit

class LoginViewController: UIViewController {

    
    @IBOutlet weak var SidSearch: UITextField!
    
    //creating global variable for holding a student
    var studentFound = Student()
    
    var isStudent = false
    var StudentsArray = students
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    
    @IBAction func LoginButtonAction(_ sender: UIButton) {
        
        let enteredID = SidSearch.text!
        for student in StudentsArray {
            if enteredID == student.sid{
                studentFound = student
                isStudent = true
                              
                          }
                      }
                  }
                  
                  
                  override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
                      let transition = segue.identifier
                      if transition == "studentInfoSegue"{
                          //Create a destination of type studentInfoViewController
                          let destination = segue.destination as! StudentInfoViewController
                          
                          //if student is exists in the array, we will assign the studentObj in the destination with "studentFound"
                          if isStudent {
                              destination.studentObj = studentFound
                          }else{
                              //if the given sid is not in the array, then the student is a guest!!
                              //we set the boolean in the destination as true!!
                              destination.guestUser = true
                          }
                          
                          
                      }
                  }
                  
              }
