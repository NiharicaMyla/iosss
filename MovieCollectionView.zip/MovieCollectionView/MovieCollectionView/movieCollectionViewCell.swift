//
//  movieCollectionViewCell.swift
//  MovieCollectionView
//
//  Created by Myla,Niharica on 4/12/22.
//

import UIKit

class movieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageviewoutlet: UIImageView!
    
    func assignMovies( _ movie: Movie) {
        imageviewoutlet.image = movie.image
        
    }
    
 
    
    
}
