//
//  ViewController.swift
//  CoursesDisplayApp
//
//  Created by Myla,Niharica on 2/10/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ImageViewOutlet: UIImageView!
    
    
    @IBOutlet weak var CrsNum: UILabel!
    
    
    @IBOutlet weak var CrsTitle: UILabel!
    
    @IBOutlet weak var CrsSemester: UILabel!
    
    @IBOutlet weak var Previousbtn: UIButton!
    
    @IBOutlet weak var NextBtn: UIButton!
    
    
    
    let courses = [["img01", "44555", "Network Security", "Fall 2022"],
    ["img02", "44643", "IOS", "Spring 2022"],
    ["img03", "44656", "Streaming Data", "Summer 2022"]
    ]
    
    var imageNumber = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    //In the view didload, it should load the details of the first course(oth ele,img,num,title n sem)
        updateUI(imageNumber);
       
        //previous button is disabled
        Previousbtn.isEnabled = false;
    }

    @IBAction func PreviousBtnclicked(_ sender: UIButton) {
        //this function should be able to take me back to previous page
        //next button should be enabled
        NextBtn.isEnabled = true
        //update UI and
        imageNumber -= 1
        updateUI(imageNumber)
        
        //if the course position is at the 0th, previous button should be disabled
        if(imageNumber == 0) {
            Previousbtn.isEnabled = false
        }
        
        
    }
    
    
    @IBAction func Nextbtnclicked(_ sender: UIButton) {
        //when next btn is clicked, UI should be updated with the next course details.
        
        imageNumber += 1
        updateUI(imageNumber)
        //previous btn should be enabled
        Previousbtn.isEnabled = true;
        //once reaching the courses end array, next btn should be disabled
        
        if(imageNumber == courses.count-1) {
            NextBtn.isEnabled = false
        }
        
        
    }
    
    func updateUI(_ imageNumber: Int) {
        ImageViewOutlet.image = UIImage(named: courses[imageNumber][0])
        CrsNum.text = courses[imageNumber][1]
        CrsTitle.text = courses[imageNumber][2]
        CrsSemester.text = courses[imageNumber][3]
    }
}

